//: Playground - noun: a place where people can play

import UIKit

enum Velocidades : Int {
    case Apagado = 0, VelocidadBaja = 20 , VelocidadMedia = 50, VelocidadAlta = 120
    
    init( velocidadInicial : Velocidades ){
        self = velocidadInicial
    }
}

//var velocidadI = Velocidades.Apagado
//var velocidad = Velocidades(velocidadInicial: velocidadI)

class Auto {
    
    var velocidad1 : Velocidades

    init( velocidad1 : Velocidades){
        self.velocidad1 = velocidad1
    }
    
    
    func cambioDeVelocidad() -> ( actual : Int, velocidadEnCadena: String){
    
        let velocidadActual = velocidad1

        switch velocidadActual {
        case .Apagado:
            //print("Apagado, siguiente = 20")
            velocidad1 = Velocidades.VelocidadBaja
            
        case .VelocidadBaja:
            velocidad1 = Velocidades.VelocidadMedia
        case .VelocidadMedia:
            velocidad1 = Velocidades.VelocidadAlta
        case .VelocidadAlta:
            velocidad1 = Velocidades.VelocidadMedia
        }
        return(velocidad1.rawValue,  String(velocidad1))
    }

}


var auto : Auto
var auto1 = Auto(velocidad1:Velocidades.Apagado)


for index in 1...20 {
    print(auto1.velocidad1.rawValue, auto1.velocidad1)
    auto1.cambioDeVelocidad()
}





